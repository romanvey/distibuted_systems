db.items.find({
	"category": "Phone"
}).count();
