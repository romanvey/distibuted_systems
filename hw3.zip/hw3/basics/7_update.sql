db.items.update({
	"category": "TV"
	},
	{
	    	$set: {
	    		"diagonal": 40    
	    	}
	}, 
	{
    multi: true
});
