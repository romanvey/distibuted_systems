db.items.find({}).pretty();
