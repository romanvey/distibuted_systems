db.items.update(
	{
   		"diagonal": {
			$exists: true
   		}          
	},
	{
	    	$inc: {
	    		"price": 50    
	    	}
	}, 
	{
    multi: true
});
