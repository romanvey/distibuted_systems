db.items.distinct("category").length;
