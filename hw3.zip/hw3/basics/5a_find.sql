db.items.find({
    $and: [
    {
		"category": "Phone"
	},
	{
	    "price": {
	     $gt:499,
	     $lt:601   
	    }
	}
	]
});
