db.items.find({
    $or: [
    {
		"model": "IPhone 6"
	},
	{
	    "price": 400
	}
	]
});
