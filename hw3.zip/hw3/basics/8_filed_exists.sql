db.items.find(
{
   "diagonal": {
		$exists: true
   }          
});
