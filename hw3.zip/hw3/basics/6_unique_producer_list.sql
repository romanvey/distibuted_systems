db.items.distinct("producer");
