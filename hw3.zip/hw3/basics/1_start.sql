use shop;
db.createCollection("items");

db.items.insertMany([
{
    "category" : "Phone",
    "model" : "iPhone 6",
    "producer" : "Apple",
    "price" : 600
},
{
    "category" : "Phone",
    "model" : "iPhone 5",
    "producer" : "Apple",
    "price" : 500
},
{
    "category" : "Phone",
    "model" : "iPhone 4",
    "producer" : "Apple",
    "price" : 400
},
{
    "category" : "Phone",
    "model" : "Samsung S3",
    "producer" : "Samsung",
    "price" : 200
},
{
    "category" : "Phone",
    "model" : "Samsung S4",
    "producer" : "Samsung",
    "price" : 400
},
{
    "category" : "TV",
    "model" : "Samsung TV 2",
    "producer" : "Samsung",
    "price" : 1000
},
{
    "category" : "TV",
    "model" : "Samsung TV",
    "producer" : "Samsung",
    "price" : 900
},
{
    "category" : "Smart Watch",
    "model" : "iWatch",
    "producer" : "Apple",
    "price" : 400
},
{
    "category" : "Smart Watch",
    "model" : "Samsung Galaxy Watch",
    "producer" : "Samsung",
    "price" : 300
}]);
