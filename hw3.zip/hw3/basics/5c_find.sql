db.items.find({
    "model": {
     	$in: ["iPhone 4", "iPhone 5", "iPhone 6"]   
    }
});
