db.getCollection("order").find({"order_items_id": {
		$elemMatch: DBRef("items", ObjectId("5c73baa5e9e55a69af759789"))
	}
});
