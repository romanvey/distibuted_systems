db.getCollection("order").find({"total_sum": {
		$gt: 1300
	}
}, 
{
	"customer": 1, "payment.cardId": 1, "_id": 0
});
