db.getCollection("order").insertMany([{    
	    "order_number" : 201513,
	    "date" : ISODate("2015-04-14"),
	    "total_sum" : 1100,
	    "customer" : {
		"name" : "Andrii",
		"surname" : "Rodinov",
		"phones" : [ 9876543, 1234567],
		"address" : "PTI, Peremohy 37, Kyiv, UA"
	    },
	    "payment" : {
		"card_owner" : "Andrii Rodionov",
		"cardId" : 12345678
	    },
	    "order_items_id" : [
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73baa5e9e55a69af759789")
		},
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73baede9e55a69af75978a")
		}
	    ]
	},
	{    
	    "order_number" : 201777,
	    "date" : ISODate("2015-06-14"),
	    "total_sum" : 1000,
	    "customer" : {
		"name" : "Andrii",
		"surname" : "Rodinov",
		"phones" : [ 9876543, 1234567],
		"address" : "PTI, Peremohy 37, Kyiv, UA"
	    },
	    "payment" : {
		"card_owner" : "Andrii Rodionov",
		"cardId" : 12345678
	    },
	    "order_items_id" : [
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73baa5e9e55a69af759789")
		},
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73bb7be9e55a69af759791")
		}
	    ]
	},
	{    
	    "order_number" : 201787,
	    "date" : ISODate("2015-06-23"),
	    "total_sum" : 800,
	    "customer" : {
		"name" : "Roman",
		"surname" : "Vei",
		"phones" : [ 9876543, 1234567],
		"address" : "PTI, Banderi 12, Kyiv, UA"
	    },
	    "payment" : {
		"card_owner" : "Roman Vei",
		"cardId" : 12345679
	    },
	    "order_items_id" : [
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73baa5e9e55a69af759789")
		},
		{
		    "$ref" : "items",
		    "$id" : ObjectId("5c73bb0fe9e55a69af75978c")
		}
	    ]
	}
]);
