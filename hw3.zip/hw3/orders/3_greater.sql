db.getCollection("order").find({"total_sum": {
		$gt: 900
	}
});
