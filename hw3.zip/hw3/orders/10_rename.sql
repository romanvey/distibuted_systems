db.getCollection("order").update({},
{
 	$set: {
 	 	"customer.name": "Max",
 	 	"customer.surname": "Good"
 	}  
},
{
 	multi: true
});

