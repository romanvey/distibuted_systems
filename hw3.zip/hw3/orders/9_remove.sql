db.getCollection("order").update({
	"date": {
	 	$gt: ISODate("2015-06-10T00:00:00.000+0000"),
	 	$lt: ISODate("2015-06-25T00:00:00.000+0000") 
	}   
},
{
 	$pull: {
 	 	order_items_id: DBRef("items", ObjectId("5c73bb69e9e55a69af759790"))
 	}   
},
{
 	multi: true
});
