db.getCollection("order").find({
	"customer": {
	 	"name": "Roman",
	 	"surname": "Vei",
	 	"phones" : [
            9876543.0, 
            1234567.0
        ], 
        "address" : "PTI, Banderi 12, Kyiv, UA"
	}
});
