db.getCollection("order").aggregate([
    {
        $match: {
            "customer": {
                "name": "Max",
                "surname": "Good",
                "phones": [
                    9876543.0,
                    1234567.0
                ],
                "address": "PTI, Peremohy 37, Kyiv, UA"
            }
        }

    },

    {
        $project: {
            "order_items_id": 1,
            "customer": 1,
            "_id": 0
        }
    },
    {
     	$unwind: "$order_items_id"
    },
    {
     	$lookup: {
     	 	from: "items",
     	 	localField: "order_items_id.$id",
     	 	foreignField: "_id",
     	 	as: "order"
     	}   
    }
]); 


!!! lookup not working vs DBRefs, so this solution not full
