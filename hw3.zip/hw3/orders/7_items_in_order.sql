db.getCollection("order").findOne({"order_number": 201777}).order_items_id.length
